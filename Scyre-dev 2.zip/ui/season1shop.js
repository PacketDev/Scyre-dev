module.exports = {
  //this is a test so it dont work 
			"refreshIntervalHrs": 24,
			"dailyPurchaseHrs": 24,
			"expiration": "2021-12-12T01:12:00Z",
			"storefronts": [
			  {
				"name": "BRDailyStorefront",
				"catalogEntries": [
          {   
            "offerId": "425FDD804D9D61AC2530CE8F31398BCD",
            "devName": "Large Currency Pack",
            "offerType": "StaticPrice",
            "prices": [
           {
            "currencyType": "RealMoney",
            "currencySubType": "",
            "regularPrice": 0,
            "dynamicRegularPrice": -1,
            "finalPrice": 0,
            "saleExpiration": "9999-12-31T23:59:59.999Z",
            "basePrice": 0
            }
            ], 
            "categories": [ ],
            "dailyLimit": -1,
            "weeklyLimit": -1,
            "monthlyLimit": -1,
            "refundable": false,
         }
        ]
			  },
			  {
				"name": "BRWeeklyStorefront",
				"catalogEntries": [
          {

          }
        ]
			  }
			]
		}