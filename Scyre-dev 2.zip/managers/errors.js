console.log("Found Errors File")
// ill add stuff i guess here soon